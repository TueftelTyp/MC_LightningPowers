package de.mcrising.lightningpowers;

import de.mcrising.lightningpowers.config.PowerConfig;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.Equippable;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.level.Level;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class LightningPowers implements ModInitializer {
    public static final String MOD_ID = "lightningpowers";
    private static final ResourceLocation HELMET_ID = ResourceLocation.fromNamespaceAndPath(MOD_ID, "lightning_helmet");
    public static Item HELMET;
    private static final Map<UUID, Charge> ACTIVE = new HashMap<>();
    private static final Map<UUID, Long> COOLDOWNS = new HashMap<>();
    private record Charge(long untilTick) {}
    private static long tick = 0;

    @Override public void onInitialize() {
        PowerConfig.load();
        HELMET = Registry.register(BuiltInRegistries.ITEM, HELMET_ID,
           new Item(new Item.Properties()
             .setId(ResourceKey.create(Registries.ITEM, HELMET_ID))
             .stacksTo(1).durability(384)
             .component(DataComponents.EQUIPPABLE, Equippable.builder(EquipmentSlot.HEAD).build())));
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tick++;
            if ((tick % 20) == 0) {
                for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                    Charge charge = ACTIVE.get(player.getUUID());
                    if (charge == null) continue;
                    if (tick >= charge.untilTick() || !player.isAlive()) {
                        ACTIVE.remove(player.getUUID());
                        continue;
                    }
                    if (PowerConfig.INSTANCE.applyEffectsDuringCharge) applyEffects(player);
                    if (PowerConfig.INSTANCE.electricParticles) {
                        ((net.minecraft.server.level.ServerLevel) player.level()).sendParticles(
                            ParticleTypes.ELECTRIC_SPARK, player.getX(), player.getY() + 1, player.getZ(),
                            16, .4, .7, .4, .05);
                    }
                }
            }
        });
    }

    private static boolean wearingHelmet(ServerPlayer player) {
        return player.getItemBySlot(EquipmentSlot.HEAD).is(HELMET);
    }

    public static boolean onLightning(ServerPlayer player) {
        PowerConfig cfg = PowerConfig.INSTANCE;
        if (!cfg.enabled || !wearingHelmet(player)) return false;
        if (tick < COOLDOWNS.getOrDefault(player.getUUID(), 0L)) return cfg.preventLightningDamage;
        if (!cfg.reactivationResetsDuration && ACTIVE.containsKey(player.getUUID()) && isCharged(player))
            return cfg.preventLightningDamage;
        if (cfg.refillHealth) player.setHealth(player.getMaxHealth());
        if (cfg.refillFood) {
            player.getFoodData().setFoodLevel(cfg.foodLevel);
            player.getFoodData().setSaturation(cfg.saturation);
        }
        long duration = (long) cfg.durationSeconds * 20;
        ACTIVE.put(player.getUUID(), new Charge(tick + duration));
        COOLDOWNS.put(player.getUUID(), tick + (long) cfg.cooldownSeconds * 20);
        applyEffects(player);
        if (cfg.damageHelmet && cfg.helmetDamagePerStrike > 0) {
            ItemStack helmet = player.getItemBySlot(EquipmentSlot.HEAD);
            helmet.hurtAndBreak(cfg.helmetDamagePerStrike, player, EquipmentSlot.HEAD);
        }
        return cfg.preventLightningDamage;
    }

    public static boolean isCharged(Player player) {
        Charge charge = ACTIVE.get(player.getUUID());
        return charge != null && tick < charge.untilTick() && player.isAlive();
    }

    public static void electricAttack(Player player, net.minecraft.world.entity.Entity target) {
        PowerConfig cfg = PowerConfig.INSTANCE;
        if (!cfg.enabled || !cfg.electricMelee || cfg.electricBonusDamage <= 0 || !isCharged(player)) return;
        if (!(player instanceof ServerPlayer serverPlayer) || !(target instanceof LivingEntity living)) return;
        if (!(player.level() instanceof net.minecraft.server.level.ServerLevel level)) return;
        living.hurtServer(level, player.damageSources().playerAttack(player), cfg.electricBonusDamage);
        if (cfg.electricParticles)
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, target.getX(), target.getY()+target.getBbHeight()/2,
                    target.getZ(), 12, .35, .35, .35, .1);
    }

    private static void applyEffects(ServerPlayer player) {
        PowerConfig cfg = PowerConfig.INSTANCE;
        for (String spec : cfg.effects) {
            try {
                String[] parts = spec.trim().split(":");
                if (parts.length != 3) continue;
                ResourceLocation id = ResourceLocation.fromNamespaceAndPath(parts[0], parts[1]);
                int amplifier = Math.max(0, Math.min(255, Integer.parseInt(parts[2])));
                ResourceKey<MobEffect> key = ResourceKey.create(Registries.MOB_EFFECT, id);
                BuiltInRegistries.MOB_EFFECT.getHolder(key).ifPresent(effect ->
                    player.addEffect(new MobEffectInstance(effect, 65, amplifier, false, true, true)));
            } catch (Exception ignored) { /* Invalid list entry is ignored without crashing. */ }
        }
    }
}
