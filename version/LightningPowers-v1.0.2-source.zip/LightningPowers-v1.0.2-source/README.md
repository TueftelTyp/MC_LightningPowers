# Lightning Powers v1.0 — Minecraft 26.3 / Fabric

**Source release / unverified build**: the environment used to prepare the sources had no access to the Minecraft/Gradle Maven repositories and only Java 21. Therefore this is NOT a tested Minecraft mod JAR. Please run a Gradle build on Java 25, then check the code against the live 26.3 APIs.

## Features

- Craftable lightning rod helmet. Recipe: `C R C` / `C D C` where C=copper block, R=lightning rod, D=diamond helmet.
- Lightning hitting a player wearing the helmet triggers health/food refill, a timed charge, status effects and bonus electric melee damage.
- Independent configuration of duration, cooldown, health, food, saturation, damage, helmet wear, electric particles, lightning protection and effect list.
- Config UI through Mod Menu + Cloth Config; machine-readable config at `config/lightningpowers.json`.
- English and German item/settings translations.

## Building

Requires **Java 25**, Gradle 9.6 or compatible (or a Gradle wrapper generated locally), Fabric Loom 1.19 SNAPSHOT and an internet connection for first build.

```
gradle build
```

Output if successful: `build/libs/lightningpowers-1.0.0.jar`.

For Minecraft installation use Fabric Loader, Fabric API, Mod Menu v21.0.0 and Cloth Config API 26.3.159. Mod Menu and Cloth Config are client-side optional; the JSON config works without them.

For dedicated servers edit **the server's** `config/lightningpowers.json`, restart the server. Client GUI settings do **not** synchronize to a dedicated server. Single-player games use the local file.

## Effect format

Each list entry is `namespace:effect_id:amplifier`, e.g. `minecraft:strength:2` = Strength III. The last number starts at zero.

You can add any registered status effect ID (including other mods' effects) in the JSON config or via the list editor in Mod Menu. Invalid entries are ignored. Default effects: Strength III, Speed II, Jump Boost II, Resistance II, Regeneration II, Fire Resistance I, Night Vision I, Haste II.

## Known limitations

- Source code is uncompiled and untested; API mismatches may remain.
- Cooldown and active-charge state are held in memory; they reset when the Minecraft server restarts.
- The item icon currently reuses the vanilla copper helmet icon; no unique helmet texture or model is supplied.
- The electro melee hit adds damage after normal attack processing and may be affected by other mods.
- Only standard status effects from registries are extensible. New custom powers require Java code changes.


## Build-Korrektur 1.0.1
Loom-Plugin-ID fuer Minecraft 26.3 auf `net.fabricmc.fabric-loom` umgestellt. Ein vollstaendiger Java-Build wurde hier nicht ausgefuehrt.
