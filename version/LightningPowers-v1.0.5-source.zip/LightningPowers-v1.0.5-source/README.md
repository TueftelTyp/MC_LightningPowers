# Lightning Powers v1.0.5 — Minecraft 26.3 / Fabric

**Source release / unverified build**: the environment used to prepare the sources had no access to the Minecraft/Gradle Maven repositories and only Java 21. Therefore this is NOT a tested Minecraft mod JAR. Please run a Gradle build on Java 25, then check the code against the live 26.3 APIs.

## Features

- Craftable lightning rod helmet. Recipe: `C R C` / `C D C` where C=copper ingot, R=lightning rod, D=diamond helmet.
- Lightning hitting a player wearing the helmet triggers health/food refill, a timed charge, status effects and bonus electric melee damage.
- Independent configuration of duration, cooldown, health, food, saturation, damage, helmet wear, electric particles, lightning protection and effect list.
- Config UI through Mod Menu + Cloth Config; machine-readable config at `config/lightningpowers.json`.
- English and German item/settings translations.

## Building

Requires **Java 25**, Gradle 9.6 or compatible (or a Gradle wrapper generated locally), Fabric Loom 1.19 SNAPSHOT and an internet connection for first build.

```
gradle build
```

Output if successful: `build/libs/lightningpowers-1.0.5.jar`.

For Minecraft installation use Fabric Loader, Fabric API, Mod Menu v21.0.0 and Cloth Config API 26.3.159. Mod Menu and Cloth Config are client-side optional; the JSON config works without them.

For dedicated servers edit **the server's** `config/lightningpowers.json`, restart the server. Client GUI settings do **not** synchronize to a dedicated server. Single-player games use the local file.

## Effect format

Each list entry is `namespace:effect_id:amplifier`, e.g. `minecraft:strength:2` = Strength III. The last number starts at zero.

You can add any registered status effect ID (including other mods' effects) in the JSON config or via the list editor in Mod Menu. Invalid entries are ignored. Default effects: Strength III, Speed II, Jump Boost II, Resistance II, Regeneration II, Fire Resistance I, Night Vision I, Haste II.

## Known limitations

- Source code is uncompiled and untested; API mismatches may remain.
- Cooldown and active-charge state are held in memory; they reset when the Minecraft server restarts.
- The item icon currently reuses the vanilla copper helmet icon; no unique helmet texture or model is supplied.
- The electro melee hit adds damage after normal attack processing and may be affected by other mods.
- Only standard status effects from registries are extensible. New custom powers require Java code changes.


## Build-Korrektur 1.0.1
Loom-Plugin-ID fuer Minecraft 26.3 auf `net.fabricmc.fabric-loom` umgestellt. Ein vollstaendiger Java-Build wurde hier nicht ausgefuehrt.


## v1.0.3
Minecraft 26.3 Java API Anpassungen: Identifier, Equippable Paket, Registry Holder Lookup. Java Build ist hier nicht verifiziert.


## v1.0.4 - Graphics and 3D helmet

- Logo A (copper shield/lightning) as Mod Menu mod icon.
- Hand-pixelled 32x32 helmet inventory textures based on concept B.
- Wearable voxel/block-model based on concept D with actual lightning-rod cuboids (head render context).
- Normal and charged inventory textures and worn 3D models; selected on server through ITEM_MODEL component.
- Head equipment uses the vanilla head-item renderer; no extra rendering library required.
- F5 third-person view to verify model, lightning strike to verify charge.

**Note:** Graphics and JSON are checked locally; full Gradle Java build and in-game rendering cannot be verified in this environment (no Java 25/Gradle or Minecraft client).


## v1.0.5 - Crafting + Creative Inventory

- Recipe now uses four **copper ingots**, not copper blocks, matching the in-game grid in the reported screenshot: first row `CRC`; second row `CDC`; third row empty. R=lightning rod, D=diamond helmet.
- Added helmet to Creative > Combat using `CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT)`; Creative search also includes it. Search German: `Blitzableiter-Helm`, English: `Lightning Rod Helmet`.
- Use `/give @s lightningpowers:lightning_helmet` to test item registration.
- If testing a rebuilt JAR, remove the older Lightning Powers JAR from the mods folder first. Restart game, reload world.
- Build still needs verification with Java 25 and the Minecraft/Fabric dependencies.
